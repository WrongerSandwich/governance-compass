# Handoff: Governance Compass — visual redesign (home, quiz, results, reference)

## Overview

A visual redesign of [governance-compass](https://github.com/WrongerSandwich/governance-compass) — a twelve-axis political self-assessment. The brief: the site read as too plain, and gave no sense of the results payoff before you invested fifteen minutes in the quiz. The redesign keeps the existing "Cartographic Stone" palette intact and changes the *treatment* layer — a monospace label system, near-square corners, an ink-filled primary button, ruled sections instead of floating cards, and a new paired axis-scale component that puts a sample of the results payoff directly on the home page.

This is a **delta against the existing design system, not a replacement.** No new colours were introduced. Every hex in this bundle already exists in `src/app/globals.css` or `src/lib/design-tokens.ts`.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes showing intended look and behaviour, not production code to copy. They are Design Components (`.dc.html`), which open directly in a browser; open them by loading the `.dc.html` file with `support.js` and the two `.woff2` files alongside it.

The task is to **recreate these designs in the existing Next.js + Tailwind codebase**, using its established patterns: CSS custom properties in `globals.css`, the `@theme inline` Tailwind mapping, and the existing component structure under `src/components/`. Do not port the HTML. In particular:

- Keep every existing component boundary (`ForcedChoiceCard`, `ProgressBar`, `ScoreBar`, `AxisBreakdownCard`, `ArchetypeCard`, `ResultsView`, `QuizFlow`). This redesign restyles them; it does not restructure the app.
- Keep all existing behaviour: seeded shuffle, autosave/resume, skip, keyboard 1–5 on scales, glossary annotation, URL-encoded results, reduced-motion handling.
- Add tokens to `globals.css` rather than hard-coding values in components.

## Fidelity

**High-fidelity.** Colours, typography, spacing and states are final and specified below to the pixel. Recreate them exactly, using the codebase's existing Tailwind/token mechanisms.

Two caveats that are *deliberately* not final:

1. **All data is fabricated.** Every score, match percentage, archetype assignment and paired profile in these mocks exists to exercise the layout. Wire them to real scoring output.
2. **The home page's sample profile** shows an invented archetype name in some earlier iterations. Use a real name from `src/data/archetypes.ts`, or label the sample explicitly as illustrative in shipped copy.

---

## Design tokens

### Colours — all unchanged, all already in `globals.css`

| Role | Light | Dark | Token |
| --- | --- | --- | --- |
| Page ground | `#efe9e3` | `#17120d` | `--surface-3` |
| Data panel | `#ffffff` | `#2a2118` | `--surface-1` |
| Quiet band | `#f7f4f0` | `#1f1812` | `--surface-2` |
| Primary text | `#3d2e1f` | `#efe9e3` | `--text-primary` |
| Secondary text | `#6e5a48` | `#cdbfb2` | `--text-secondary` |
| Label / tertiary text | `#9d8b78` | `#9d8b78` | `--text-tertiary` |
| Section rule | `#e0d6cc` | `#3d2e1f` | `--border-secondary` |
| Control outline / header rule | `#cdbfb2` | `#5a4636` | `--border-primary` |
| Progress fill, focus ring | `#85735e` | `#85735e` | `--stone-600` |
| Warning text (tensions) | `#92400e` | `#fbbf24` | `--warning-text` |

Domain colours (from `DOMAIN_COLORS` in `src/lib/design-tokens.ts`) are unchanged:
Economic `#85735e` / 400 `#b5a594` · Power `#6b7d8a` / 400 `#9daebb` · Society `#7a8b6e` / 400 `#94a488` · World `#96716b` / 400 `#c1a7a1`.

**Dark mode rule:** the primary button inverts rather than darkens — Stone 300 `#cdbfb2` fill with Stone 900 `#3d2e1f` text. Data marks (dots, tracks, domain labels) step from domain 600 to domain 400. Stone 500 `#9d8b78` holds as the label colour in both modes.

### Type scale

Families are unchanged: `--font-serif` (Source Serif 4), `--font-sans` (system-ui), `--font-mono` (ui-monospace).

| Step | Spec | Use |
| --- | --- | --- |
| display-xl | 58px / 1.04 / −0.021em, serif 500 | Home headline, desktop. Measure ~11em. |
| display-page | 40px / 1.06 / −0.02em, serif 500 | Interior page titles (results, reference, methodology). |
| display-l | 34px / 1.06 / −0.018em, serif 500 | Home headline on mobile; large numerals (match %). |
| display-m | 26px / 1.2, serif 500 | Section headings. **Not** the quiz prompt. |
| display-entry | 22px / 1.2, serif 500 | Entry titles in long reference lists. |
| display-s | 17px / 1.35, serif 500 | Card titles, forced-choice option headlines, archetype name in results hero. |
| body-lead | 17px / 1.62, sans | Lead paragraph. |
| body | 14–15.5px / 1.6–1.65, sans | Prose. Secondary prose drops to 14px in Stone 500. |
| label | 11px mono, 0.10–0.14em, uppercase | Eyebrows, section labels, counts, axis endpoints, status. 0.14em on eyebrows, 0.12em inside panels, 0.10em on nav links. |
| control | 12px mono, 0.12em, uppercase, 500 | Button labels. Wordmark uses 0.16em. |
| caption-italic | 13.5–14px serif italic, Stone 500 | Explanatory captions under section headings. |

**Type floor: 11px.** Nothing renders below it, desktop or mobile.

### Other tokens

- **Radius:** `2px` everywhere buttons and cards previously used `rounded-[12px]` or `rounded-[8px]`. Circles (dots, compass mark) unaffected. Suggest adding `--radius: 2px` to `:root`.
- **Rule weights:** 1px Stone 900 (under a card's own header) · 2px domain colour (above a domain block, or as a 2px left border on a callout) · 1px Stone 200 (section boundaries) · 1px Stone 50 (row separators inside a list).
- **Spacing:** section padding 40–68px vertical desktop, 26–34px mobile; page gutters 28px desktop / 18px mobile; card padding 22–26px; row padding 9–12px vertical.
- **Content widths:** home 1040px max with 56px gutters; results/quiz body 672–820px centred; reference column 660px. Prose measure 60–62ch.
- **Motion:** unchanged from the current codebase — `petal-reveal`, `fade-in-up`, `loading-slide`, and the `prefers-reduced-motion` collapse.

---

## Screens

### 1. Home (`src/app/page.tsx`) — reference: `Home proposals.dc.html` → option **5a** (desktop), **6a** (mobile)

**Purpose.** Explain the instrument and get a visitor into the assessment, while showing what the output actually looks like.

**Layout, desktop (1040px).**

1. **Nav**, 54px tall, `--surface-1`, 1px bottom rule. Left: 22px compass mark + wordmark at 12px mono uppercase 0.16em. Right: Quiz · Methodology · Research at 11px mono uppercase 0.10em, Stone 700.
2. **Hero**, 66px top padding, 56px gutters, max-width 800px. Eyebrow label ("A twelve-axis self-assessment") → h1 at display-xl, max-width 11em → 17px lead paragraph, max-width 34em → 14px secondary paragraph in Stone 500 → button row.
   Buttons: primary "Begin the assessment" (ink fill, 15px/34px padding); tertiary "Methodology" (11px mono, 1px Stone 300 underline, 3px offset); then "~15 min · no account required" in 14px serif italic Stone 500.
3. **Payoff block**, 44px top padding, grid `1fr 356px`, 28px gap.
   *Left panel* (white, 1px Stone 200, 2px radius, 24/26px padding): header row "Illustrative profile" + A/B legend, 1px Stone 900 rule beneath, then twelve paired axis-scale rows (below).
   *Right column*, 20px gap: "Where the two diverge" panel — three items, each a 2px domain-coloured left border, 14px serif title, 12.5px body; then an "Internal tension" panel on Stone 50.
4. **Domain footer** on `--surface-1`: label, then a four-column grid (30px gap), each column a 2px domain rule, domain index label, 15px serif name, 12.5px blurb, and its axes as 11px mono `NN Pole ←→ Pole`.
5. **Footer**: 1px rule, 11px mono, privacy claims left, source/licence right.

**Mobile (390px).** Single column; gutters 18px; h1 at display-l; primary button full-width 16px padding (48px tall), outlined "Methodology" below it; the paired table becomes one ruled list (axis name row, scale, endpoints beneath); domain columns stack.

**Copy (exact).**
- Eyebrow: `A twelve-axis self-assessment`
- H1: `Locating a political position across twelve axes.`
- Lead: `Economic organization, the distribution of authority, social and cultural questions, and a state's conduct abroad — each measured separately, reported with its reasoning, and comparable with another respondent's.`
- Secondary: `Fifteen minutes of applied dilemmas, calibration scales, and budget allocations produce a surveyed position on all twelve axes.`
- Buttons: `Begin the assessment` · `Methodology` · meta `~15 min · no account required`

### 2. Quiz, phase 1 (`src/components/quiz/QuizFlow.tsx`, `ForcedChoiceCard.tsx`, `ProgressBar.tsx`) — reference: `Home proposals.dc.html` → **6b**

**Purpose.** Answer one forced-choice dilemma. Restyle only — the flow, state and controls are exactly what `QuizFlow` already renders.

**Layout.** Nav as home. Body max-width 672px, 36px top padding.

1. **Progress.** Row: `Phase 1 · Dilemmas` left, `2 of 36` right, both 11px mono uppercase 0.10em Stone 700, 10px below. Then three equal segments, 3px tall, 4px gap, track `--border-secondary`, fill Stone 600 at `(index+1)/total`; completed segments 100%. 32px below.
2. **Glossary hint** (first question only, matching the existing `glossaryHintSeen` condition): centred 12.5px Stone 500, with "highlighted term" carrying a dotted underline in `#C4A84A`, 3px offset.
3. **Prompt.** 11px mono uppercase 0.12em Stone 500 — `Select the position closer to your own view` (or the `PT` variant already in the component). **Not** a serif heading.
4. **Options.** Two-column grid, 16px gap (single column below 560px). Each card: white, 2px radius, 24px padding. Headline display-s serif; body 13.5px/1.6 Stone 700. Selected = 1px Stone 900 border plus a `Selected` marker in 11px mono uppercase; unselected-with-selection = 1px Stone 200 border at 60% opacity; hover = Stone 600 border.
5. **Navigation.** 32px above; `Previous` outlined left, `Next` ink-filled right, both 12px mono uppercase. Disabled states unchanged (50% opacity). The "Skip this question" text button keeps its existing placement and condition.

Glossary terms keep `AnnotatedText` + `GlossaryTerm` exactly as they work today.

### 3. Results (`src/components/results/ResultsView.tsx`) — reference: `Page mocks.dc.html` → **7a** (light), **7b** (dark)

**Purpose.** Deliver the profile. Section order is unchanged from `ResultsView`.

**Layout.** Body max-width 820px, 48px top padding.

1. **Header.** Eyebrow `Assessment results` → h1 at display-page (archetype name, or `A distinctive profile`) → 16px sub `74% match — your compass across twelve axes.` → jump nav: 11px mono uppercase links, 12px padding, rules above and below.
2. **Archetype panel** (white, 1px Stone 200, 2px radius, 26px padding), grid `1fr 220px`:
   *Left* — `Primary archetype` label with 1px Stone 900 rule beneath; match percentage at display-l (34px serif); archetype name at display-s; 13.5px summary; then the action row: `Copy link` and `Compare with someone` as outlined 11px mono buttons, `Learn more` as a tertiary link. Below the panel body, a 1px Stone 50 rule and `Adjacent · <name> — NN% match` in 11px mono.
   *Right* — the existing 200px mini radar: background ring and dashed mid-ring in `--border-secondary`, prototype polygon dashed Stone 500 at 50% opacity, user polygon Stone 600 (fill 12%, stroke 1.4). Legend beneath in 11px mono.
3. **Radar section.** Eyebrow → display-m heading `Twelve-axis radar` → serif italic caption → white panel, 28px padding, containing the 12-spoke radar: outer ring 0.8px Stone 200, dashed mid-ring Stone 300, spokes 0.6px, user polygon Stone 600 (10% fill), a 4px dot per axis in that axis's domain 600, and axis labels at r+22 in 11px mono Stone 700 (`NN PoleA`), anchored `start`/`middle`/`end` by quadrant. Same `((score+1)/2)*R` mapping as the existing chart.
4. **Tensions.** Eyebrow → display-m `Principles against priorities` → serif italic caption → per tension, a white panel with a 2px `--warning` left border, an 11px mono uppercase title (`Moderate tension · Rights Balance`) in `--warning-text`, and the existing narrative sentence at 13.5px.
5. **Axis breakdown.** display-m heading with a tertiary `Show scoring details` link on the right, serif italic caption, then four domain groups. Each group: 2px domain rule, domain name in 11px mono uppercase *in the domain colour*, axis count right-aligned in Stone 500. Each axis row is a grid `24px 1fr 210px`: index, then (axis name 13.5px + signed score in 11px mono on one line, the scale below, endpoints beneath in 11px mono), then confidence label and tagline in Stone 500. Rows separated by 1px Stone 200 — no zebra fill, no card radius.
6. **Compass plot.** Eyebrow → display-m → caption → white panel with a 300px square, 50px grid lines in Stone 50, 1px Stone 200 axes, a 12px Stone 900 dot, and four 11px mono pole labels.

**Dark mode.** Exactly as the table above: ground `#17120d`, panels `#2a2118`, rules `#3d2e1f`, header rules `#5a4636`, primary button Stone 300 on Stone 900 text, data marks at domain 400, warning text `#fbbf24`, labels unchanged at Stone 500.

### 4. Archetype reference (`src/app/archetypes/page.tsx`) — reference: `Page mocks.dc.html` → **7c**

**Purpose.** The densest prose page; the test of how far the mono layer travels. Answer: it frames, it does not enter.

**Layout.** Column 660px, 44px top padding.

1. Back link in 11px mono uppercase → h1 at display-page → two 15px/1.65 intro paragraphs.
2. **Spoiler note**: 2px `--warning` left border, 16px left padding, 14px prose, serif italic lead-in in `--warning-text`, inline link underlined in Stone 300.
3. **Provenance legend**: 11px mono uppercase label, then three rows — glyph (● ◐ ○) in Stone 600, tier name in 11px mono uppercase Stone 900, then prose.
4. **Index**: two-column grid; each entry is `NN` in 11px mono Stone 500, name in 13px sans, tier glyph in Stone 600.
5. **Entries**: full-bleed zebra rows (white / Stone 50), 1px Stone 200 separators, inner column 660px, 30px padding. Header: `NN` 12px mono, name at display-entry, tier glyph, tier name in 11px mono uppercase beneath; 72px mini radar right (rings in Stone 200, prototype polygon Stone 600 at 14% fill). Body: description 14.5px; then `Internal tension.` and `Traditions.` as **serif italic lead-ins in Stone 900** followed by sans prose — these survive the redesign deliberately. Disclosure summary `▸ Axis positions` in 11px mono uppercase.
6. **Footer**: ink primary `Begin the assessment` centred, then tertiary nav links in 11px mono.

---

## Interactions & behaviour

Nothing in the interaction model changes. For completeness:

- **Quiz.** Selecting an option records the response; `Next` is disabled until a response exists; `Previous` is disabled on the first item; the last item's `Next` reads `Continue`. Skip is available while unanswered. Progress persists via the existing quiz-state storage; a mid-quiz reload shows the resume screen. Keyboard 1–5 selects on scale questions.
- **Results.** `Copy link` copies `window.location.href` and shows `Copied!` for 2s. `Compare with someone` expands an inline input that accepts a pasted results URL or raw code and routes to `/compare`. Section jump links scroll to their anchors. `Show scoring details` toggles the per-axis breakdown disclosures.
- **Reference.** `Axis positions` is a native `<details>` disclosure; the caret rotates 90° on open. `:target` highlight on archetype entries is unchanged.
- **Hover states.** Primary button → Stone 800 (dark mode: Stone 200). Outlined controls → Stone 50 background (dark: `--surface-2`). Tertiary links → Stone 900 text. Choice cards → Stone 600 border. All transitions 150ms, colour only.
- **Focus.** Unchanged: 2px Stone 600 outline, 2px offset.
- **Responsive.** Single breakpoint behaviour matching the codebase's `min-[560px]`: two-column option grids, domain grids and hero grids collapse to one column; buttons go full-width at ≥48px tall; the paired table becomes a stacked ruled list.

## State management

No new state. Existing state is unchanged: quiz reducer (phase, index, three response maps, seed), resume acknowledgement, `showScoring` on results, per-card expansion, copy-confirmation timer, compare-input open/value.

## Assets

- `SourceSerif4-latin-variable.woff2` and `SourceSerif4-latin-variable-italic.woff2` — copied from `src/app/fonts/`, unchanged.
- The compass mark is the existing `GovernanceCompassMark` SVG (four petals in Stone 600 / Slate 600 / Sage 600 / Clay 600 at varying opacity, Stone 600 hub). In dark mode the petals use the 400-level domain tones and a Stone 300 hub.
- No new imagery.

## Files in this bundle

| File | What it is |
| --- | --- |
| `Design system delta.dc.html` | **Read first.** The six deltas, the type scale, the unchanged rules, and the recorded decisions. |
| `Home proposals.dc.html` | All home-page iterations, newest first. The chosen direction is **5a**; **6a** is its mobile layout; **6b** is quiz phase 1. Earlier turns (1a–4b) are superseded history. |
| `Page mocks.dc.html` | **7a** results light, **7b** results dark, **7c** archetype reference. |
| `Home (current).dc.html` | Faithful recreation of the *existing* home page, for before/after comparison. |
| `support.js`, `*.woff2` | Runtime and fonts needed to open the `.dc.html` files locally. |
| `github.md` | Repo association and the screen → source-file map. |

## Suggested implementation order

1. Add `--radius` and the mono label utilities to `globals.css`; convert `rounded-[12px]`/`rounded-[8px]` literals.
2. Restyle the shared chrome: `NavBar`, `Footer`, buttons.
3. Home page (`page.tsx`) — this needs the new paired axis-scale component; build it here.
4. Quiz phase 1, then phases 2–3 by extension (`ScaledQuestionCard`, `BudgetSimulator` are not drawn — follow the same rules).
5. Results: converge `ScoreBar` / `ComparisonScoreBar` on the paired axis scale, then `AxisBreakdownCard`, `ArchetypeCard`, `ResultsView`.
6. Archetype reference; then compare, study and methodology by extension — these are not drawn either.
