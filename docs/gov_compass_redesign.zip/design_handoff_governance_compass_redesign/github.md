repo: WrongerSandwich/governance-compass
branch: main

## Last sync

date: 2026-09-09T00:19:00Z

### Updated in this project

- Recreated the current home page from source (Home (current).dc.html).
- Six rounds of home-page proposals; direction settled on 5a.
- Added a mobile home (6a) and a phase-1 quiz page (6b) in the 5a system.
- Rebuilt 6b's shell from QuizFlow (progress, glossary hint, Previous/Next, no axis attribution).
- Wrote Design system delta.dc.html — five deltas against Cartographic Stone, plus what stays fixed.
- Mocked the results page (light + dark) and the archetype reference in the new system.
- Copied the self-hosted Source Serif 4 variable fonts.

## Screen map

| Project screen | Repo files |
| --- | --- |
| Home (current).dc.html | src/app/page.tsx, src/app/layout.tsx, src/app/globals.css, src/components/NavBar.tsx, src/components/Footer.tsx, src/components/GovernanceCompassMark.tsx, src/components/CountUp.tsx, src/components/StaggeredList.tsx, src/components/ReturningUserLink.tsx, src/data/axes.ts |
| Home proposals.dc.html — turns 1–5 (home) | same as above + src/lib/design-tokens.ts |
| Home proposals.dc.html — 6b (quiz) | src/components/quiz/QuizFlow.tsx, src/app/quiz/page.tsx, src/components/quiz/ForcedChoiceCard.tsx, src/components/quiz/ProgressBar.tsx, src/components/quiz/ScaledQuestionCard.tsx, src/components/AnnotatedText.tsx, src/data/forced-choice-items.ts (item fc-1-2) |
| Design system delta.dc.html | src/app/globals.css, src/lib/design-tokens.ts, src/components/quiz/QuizFlow.tsx, src/components/quiz/ProgressBar.tsx, src/components/AnnotatedText.tsx |
| Page mocks.dc.html — 7a, 7b (results) | src/components/results/ResultsView.tsx, ArchetypeCard.tsx, AxisBreakdownCard.tsx, ScoreBar.tsx, src/data/axes.ts, src/data/archetypes.ts (names/emergence), src/app/globals.css (dark tokens) |
| Page mocks.dc.html — 7c (archetypes) | src/app/archetypes/page.tsx, src/data/archetypes.ts |

## Sync history

- 2026-08-30T18:10:00Z — initial import: home page recreation + fonts.
